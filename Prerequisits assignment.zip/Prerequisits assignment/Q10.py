import pandas as pd
data = {
    "City": ["BENGALURU, CHENNAI , MUMBAI , MYSURU , PATNA , JAMMU , GANDHI NAGAR, HYDERABAD , ERNAKULAM , AMARAVATI"],
    "State": ["KA", "TN", "MH", "KA", "BH", "JK", "GJ", "TS", "KL", "AP"],
    "PIN Code": [560001, 600001, 400001, 570001, 800001, 180001, 382001, 500001, 682001, 522001]
}

df = pd.DataFrame(data)
df["City, State"] = df["City"] + ", " + df["State"]
df.to_excel("cities_with_combined_column.xlsx", index=False)
