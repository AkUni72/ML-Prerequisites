#Q5
S1 = "I am a great learner. I am going to have an awesome life."
search = S1.count("am")
print(search)
#Q6
S2 = "I work hard and shall be rewarded well"
S3 = S1 + S2
print(S3)
#Q7
import re
words = re.split(r'[ .]+', S3)
array_length = len(words)
print(words)
print(array_length)
#Q8
S1="I am a great learner. I am going to have an awesome life."
S2="I work hard and shall be rewarded well"
S3=S1+S2
S3=S3.split(".")
S3=[j for i in S3 for j in i.split()]
print(S3)
S3=[i for i in S3 if i!="I" and i!="Am" and i!="to" and i!="and" and len(i)<6]
print(len(S3))

