#Q4
import numpy as np
matrix = np.zeros((4,3))
print(matrix)
random_matrix = np.random.rand(4,3)
print("matrix with random numbers")
print(random_matrix)
print("single dimension array")
single_array = random_matrix.flatten()
print(single_array)
