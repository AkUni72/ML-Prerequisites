#Q1
import numpy as np
v1 = np.random.rand(100)
print(v1)
v1_sorted = np.sort(v1)
print("Sorted array : ", v1_sorted)
#Q2
print("v1*3")
print(v1*3)
#Q3
mean = np.mean(v1)
stdev = np.std(v1)
print("mean : ",mean)
print("standard deviation : ",stdev)
#Q11
import matplotlib.pyplot as plt
import random
V1=[]
length=100
for i in range(length):
    V1.append(random.randint(-1000,1000))
V1.sort()
plt.plot(V1,color='red')
plt.show()
#Q12
V1=[]
length=100
for i in range(length):
    V1.append(random.randint(-1000,1000))
V1.sort()
V2=[i**2 for i in V1]
plt.plot(V1,color='red')
plt.plot(V2,color='blue')
plt.show()
